import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { SearchJeansComponent } from './search-jeans/search-jeans.component';
import { JeansListComponent } from './jeans-list/jeans-list.component';



const routes: Routes = [
  
  {path:'searchJeans',component:SearchJeansComponent},
  {path:'jeansList',component:JeansListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
