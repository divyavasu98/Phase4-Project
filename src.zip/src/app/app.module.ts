import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DeleteJeansComponent } from './delete-jeans/delete-jeans.component';
import { UpdateJeansComponent } from './update-jeans/update-jeans.component';
import { SearchJeansComponent } from './search-jeans/search-jeans.component';
import { JeansListComponent } from './jeans-list/jeans-list.component';
import { CreateJeansComponent } from './create-jeans/create-jeans.component';
import { Jeans } from './jeans';
import { JeansService } from './jeans.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    DeleteJeansComponent,
    UpdateJeansComponent,
    SearchJeansComponent,
    JeansListComponent,
    CreateJeansComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [JeansService],
  bootstrap: [AppComponent]
})
export class AppModule { }
