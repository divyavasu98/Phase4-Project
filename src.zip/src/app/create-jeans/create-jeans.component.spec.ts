import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateJeansComponent } from './create-jeans.component';

describe('CreateJeansComponent', () => {
  let component: CreateJeansComponent;
  let fixture: ComponentFixture<CreateJeansComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateJeansComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateJeansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
