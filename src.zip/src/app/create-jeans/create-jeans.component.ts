import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-jeans',
  templateUrl: './create-jeans.component.html',
  styleUrls: ['./create-jeans.component.css']
})
export class CreateJeansComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
