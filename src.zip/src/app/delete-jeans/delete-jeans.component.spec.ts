import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteJeansComponent } from './delete-jeans.component';

describe('DeleteJeansComponent', () => {
  let component: DeleteJeansComponent;
  let fixture: ComponentFixture<DeleteJeansComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteJeansComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteJeansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
