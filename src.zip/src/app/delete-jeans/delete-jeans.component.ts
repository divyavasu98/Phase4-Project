import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-jeans',
  templateUrl: './delete-jeans.component.html',
  styleUrls: ['./delete-jeans.component.css']
})
export class DeleteJeansComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
