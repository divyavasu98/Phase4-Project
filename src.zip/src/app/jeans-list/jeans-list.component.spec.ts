import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JeansListComponent } from './jeans-list.component';

describe('JeansListComponent', () => {
  let component: JeansListComponent;
  let fixture: ComponentFixture<JeansListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JeansListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JeansListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
