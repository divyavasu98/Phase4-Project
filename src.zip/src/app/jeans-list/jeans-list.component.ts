import { Component, OnInit } from '@angular/core';
import { Jeans } from '../jeans' ;
import { JeansService } from '../jeans.service' ;


@Component({
  selector: 'app-jeans-list',
  templateUrl: './jeans-list.component.html',
  styleUrls: ['./jeans-list.component.css']
})
export class JeansListComponent implements OnInit {

  private jeansList:Jeans[];

  constructor(private jeansService:JeansService) { }

  ngOnInit() {
    this.jeansService.getAllJeans().subscribe(res=> {
      this.jeansList=res;
    });
  }

}
