import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Jeans } from './jeans';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class JeansService {
  private url:string;

  constructor(private http:HttpClient) {
    this.url = 'http://localhost:9300/jeans';
   }
   public createJeans(jeans:Jeans):Observable<Jeans>{
    return this.http.post<Jeans>(this.url,jeans);
  }

  public getAllJeans():Observable<Jeans[]>{
    return this.http.get<Jeans[]>(this.url);
  }
}
