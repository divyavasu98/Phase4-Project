import { Jeans } from './jeans';

describe('Jeans', () => {
  it('should create an instance', () => {
    expect(new Jeans()).toBeTruthy();
  });
});
