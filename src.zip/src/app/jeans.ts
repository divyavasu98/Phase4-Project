export class Jeans {
    brand: String;
    color: String;
    size: number;
    price: number;
    avatar: string;
}
