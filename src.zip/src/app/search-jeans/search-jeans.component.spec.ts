import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchJeansComponent } from './search-jeans.component';

describe('SearchJeansComponent', () => {
  let component: SearchJeansComponent;
  let fixture: ComponentFixture<SearchJeansComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchJeansComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchJeansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
