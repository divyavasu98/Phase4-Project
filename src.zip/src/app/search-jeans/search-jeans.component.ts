import { Component, OnInit } from '@angular/core';
import { Jeans } from '../jeans' ;
import { JeansService } from '../jeans.service' ;


@Component({
  selector: 'app-search-jeans',
  templateUrl: './search-jeans.component.html',
  styleUrls: ['./search-jeans.component.css']
})
export class SearchJeansComponent implements OnInit {
   private jeansList:Jeans[];

  constructor(private jeansService:JeansService) { }

  ngOnInit() {
    this.jeansService.getAllJeans().subscribe(res=> {

  });

}

}    