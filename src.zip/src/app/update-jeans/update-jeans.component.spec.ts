import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateJeansComponent } from './update-jeans.component';

describe('UpdateJeansComponent', () => {
  let component: UpdateJeansComponent;
  let fixture: ComponentFixture<UpdateJeansComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateJeansComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateJeansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
