import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-jeans',
  templateUrl: './update-jeans.component.html',
  styleUrls: ['./update-jeans.component.css']
})
export class UpdateJeansComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
